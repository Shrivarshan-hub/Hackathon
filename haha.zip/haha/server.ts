import express from "express";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const db = new Database("shethrive.db");

// Initialize Database
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    email TEXT UNIQUE,
    password TEXT
  );
  CREATE TABLE IF NOT EXISTS chats (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    title TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id)
  );
  CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id INTEGER,
    role TEXT,
    content TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(chat_id) REFERENCES chats(id)
  );
`);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // --- API ROUTES ---

  // Simple Auth (Demo purposes, real apps should use bcrypt/JWT)
  app.post("/api/auth/login", (req, res) => {
    const { email } = req.body;
    let user = db.prepare("SELECT * FROM users WHERE email = ?").get(email);
    if (!user) {
      const name = email.split("@")[0];
      const result = db.prepare("INSERT INTO users (name, email) VALUES (?, ?)").run(name, email);
      user = { id: result.lastInsertRowid, name, email };
    }
    res.json(user);
  });

  app.get("/api/chats/:userId", (req, res) => {
    const chats = db.prepare("SELECT * FROM chats WHERE user_id = ? ORDER BY created_at DESC").all(req.params.userId);
    res.json(chats);
  });

  app.post("/api/chats", (req, res) => {
    const { userId, title } = req.body;
    const result = db.prepare("INSERT INTO chats (user_id, title) VALUES (?, ?)").run(userId, title);
    res.json({ id: result.lastInsertRowid, title });
  });

  app.get("/api/messages/:chatId", (req, res) => {
    const messages = db.prepare("SELECT * FROM messages WHERE chat_id = ? ORDER BY created_at ASC").all(req.params.chatId);
    res.json(messages);
  });

  app.post("/api/messages", (req, res) => {
    const { chatId, role, content } = req.body;
    db.prepare("INSERT INTO messages (chat_id, role, content) VALUES (?, ?, ?)").run(chatId, role, content);
    res.json({ success: true });
  });

  app.post("/api/chat/generate", async (req, res) => {
    const { mode, history, userMessage } = req.body;
    const { GoogleGenAI } = await import("@google/genai");
    const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });
    
    const SYSTEM_INSTRUCTIONS: any = {
      coach: "You are SheThrive, an AI career coach for women. Your goal is to help women negotiate smarter, grow faster, and own your worth. Be encouraging, professional, and provide actionable advice. Focus on closing the gender pay gap and overcoming systemic barriers.",
      negotiate: "You are a Hiring Manager in a salary negotiation simulation. Be realistic, slightly firm but professional. Start by offering a base salary that is slightly below market rate. Respond to the user's negotiation attempts based on their arguments.",
      salary: "You are a salary research expert. Provide detailed market benchmarks, salary ranges, and tips for researching specific roles and industries. Use tables where appropriate.",
      mentor: "You are a career mentor. Focus on long-term growth, networking strategies, and leadership development for women in tech and corporate environments.",
      progress: "You are a career progress tracker. Help the user set goals, break them down into weekly tasks, and provide accountability.",
      recruiter: "You are a tech recruiter. Conduct a realistic mock interview or screening call. Focus on how the user presents their value and achievements."
    };

    const model = "gemini-3-flash-preview";
    const contents = [
      ...history.map((m: any) => ({
        role: m.role === 'user' ? 'user' : 'model',
        parts: [{ text: m.content }]
      })),
      {
        role: 'user',
        parts: [{ text: userMessage }]
      }
    ];

    try {
      const response = await ai.models.generateContent({
        model,
        contents,
        config: {
          systemInstruction: SYSTEM_INSTRUCTIONS[mode] || SYSTEM_INSTRUCTIONS.coach,
          temperature: 0.7,
        }
      });
      res.json({ text: response.text });
    } catch (error) {
      console.error("AI Error:", error);
      res.status(500).json({ error: "Failed to generate response" });
    }
  });

  // --- VITE MIDDLEWARE ---
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`SheThrive Server running on http://localhost:${PORT}`);
  });
}

startServer();
