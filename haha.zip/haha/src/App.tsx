import React, { useState, useEffect } from 'react';
import { User, Chat, Message, CoachingMode } from './types';
import { Sidebar } from './components/Sidebar';
import { ChatInterface } from './components/ChatInterface';
import { Auth } from './components/Auth';
import { FeatureLauncher } from './components/FeatureLauncher';
import { Sun, Moon } from 'lucide-react';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [chats, setChats] = useState<Chat[]>([]);
  const [activeChatId, setActiveChatId] = useState<number | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [isBusy, setIsBusy] = useState(false);
  const [mode, setMode] = useState<CoachingMode>('coach');
  const [isFabOpen, setIsFabOpen] = useState(false);
  const [theme, setTheme] = useState<'light' | 'dark'>('dark');
  const [intensity, setIntensity] = useState(0);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  // Auto-hide sidebar on small screens
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 1024) {
        setIsSidebarOpen(false);
      } else {
        setIsSidebarOpen(true);
      }
    };
    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
  }, [theme]);

  useEffect(() => {
    if (user) {
      fetchChats();
    }
  }, [user]);

  useEffect(() => {
    if (activeChatId) {
      fetchMessages(activeChatId);
    } else {
      setMessages([]);
    }
  }, [activeChatId]);

  const fetchChats = async () => {
    if (!user) return;
    const res = await fetch(`/api/chats/${user.id}`);
    const data = await res.json();
    setChats(data);
  };

  const fetchMessages = async (chatId: number) => {
    const res = await fetch(`/api/messages/${chatId}`);
    const data = await res.json();
    setMessages(data);
  };

  const handleSendMessage = async (content: string) => {
    if (!user) return;
    
    let currentChatId = activeChatId;

    // Create new chat if none active
    if (!currentChatId) {
      const res = await fetch('/api/chats', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user.id, title: content.slice(0, 30) + '...' })
      });
      const newChat = await res.json();
      currentChatId = newChat.id;
      setActiveChatId(currentChatId);
      fetchChats();
    }

    const userMsg: Message = { chat_id: currentChatId, role: 'user', content };
    setMessages(prev => [...prev, userMsg]);
    
    // Save user message
    await fetch('/api/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(userMsg)
    });

    setIsBusy(true);
    
    // Generate AI response via backend
    const aiRes = await fetch('/api/chat/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ mode, history: messages, userMessage: content })
    });
    const aiData = await aiRes.json();
    const aiResponse = aiData.text || "I'm sorry, I couldn't process that. Could you try again?";
    
    const aiMsg: Message = { chat_id: currentChatId, role: 'ai', content: aiResponse };
    setMessages(prev => [...prev, aiMsg]);

    // Save AI message
    await fetch('/api/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(aiMsg)
    });

    setIsBusy(false);
  };

  const handleLogout = () => {
    setUser(null);
    setActiveChatId(null);
    setMessages([]);
  };

  if (!user) {
    return (
      <div className="min-h-screen relative overflow-hidden">
        <div className="blob w-[500px] h-[500px] -top-40 -left-20 bg-radial from-[#10a37f]/30 to-transparent" />
        <div className="blob w-[400px] h-[400px] -bottom-20 -right-20 bg-radial from-[#0d9488]/30 to-transparent" />
        <Auth onLogin={setUser} />
      </div>
    );
  }

  return (
    <div className="flex h-screen relative overflow-hidden">
      {/* Intensity Overlay */}
      <div 
        className="fixed inset-0 pointer-events-none z-[99999] transition-opacity duration-300" 
        style={{ backgroundColor: `rgba(0,0,0,${intensity})` }}
      />

      {/* Background Blobs */}
      <div className="fixed inset-0 -z-10 bg-bg1">
        <div className="blob w-[500px] h-[500px] -top-40 -left-20 bg-radial from-[#10a37f]/20 to-transparent" />
        <div className="blob w-[400px] h-[400px] -bottom-20 -right-20 bg-radial from-[#0d9488]/20 to-transparent" />
        <div className="blob w-[350px] h-[350px] top-1/2 left-1/2 bg-radial from-[#6366f1]/20 to-transparent" />
      </div>

      {isSidebarOpen && (
        <Sidebar 
          user={user} 
          chats={chats} 
          activeChatId={activeChatId}
          onNewChat={() => setActiveChatId(null)}
          onSelectChat={setActiveChatId}
          onLogout={handleLogout}
          onFeatureSelect={setMode}
        />
      )}

      <main className="flex-1 flex flex-col overflow-hidden">
        <header className="h-16 flex items-center justify-between px-6 glass-panel border-b-0">
          <div className="flex items-center gap-3">
            {!isSidebarOpen && (
              <button 
                onClick={() => setIsSidebarOpen(true)}
                className="p-2 hover:bg-white/5 rounded-lg transition-all"
              >
                <div className="w-5 h-5 flex flex-col justify-between">
                  <div className="h-0.5 w-full bg-muted" />
                  <div className="h-0.5 w-full bg-muted" />
                  <div className="h-0.5 w-full bg-muted" />
                </div>
              </button>
            )}
            <div className="px-4 py-1.5 glass-panel rounded-full text-xs font-bold">
              🌿 SheThrive Coach ▾
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 bg-white/5 px-3 py-1 rounded-full border border-white/10">
              <span className="text-[10px] font-bold text-dim">DIM</span>
              <input 
                type="range" 
                min="0" max="0.7" step="0.1" 
                value={intensity}
                onChange={(e) => setIntensity(parseFloat(e.target.value))}
                className="w-12 h-1 accent-[#7c5cfc] cursor-pointer"
              />
            </div>
            <button 
              onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
              className="w-8 h-8 rounded-full glass-panel flex items-center justify-center hover:scale-110 transition-all"
            >
              {theme === 'dark' ? <Moon size={14} /> : <Sun size={14} />}
            </button>
            <div className="px-4 py-1.5 glass-panel rounded-full text-[11px] font-bold text-muted">
              ✨ {mode.charAt(0).toUpperCase() + mode.slice(1)}
            </div>
            <button 
              onClick={() => setActiveChatId(null)}
              className="px-4 py-1.5 bg-linear-to-br from-[#7c5cfc] to-[#c084fc] rounded-full text-[11px] font-bold text-white shadow-lg hover:shadow-[#7c5cfc]/30 transition-all"
            >
              + New Chat
            </button>
          </div>
        </header>

        <ChatInterface 
          messages={messages}
          onSendMessage={handleSendMessage}
          isBusy={isBusy}
          mode={mode}
          userName={user.name}
        />
      </main>

      <FeatureLauncher 
        isOpen={isFabOpen} 
        onClose={() => setIsFabOpen(false)} 
        onSelect={setMode}
        onOpen={() => setIsFabOpen(true)}
      />
    </div>
  );
}
