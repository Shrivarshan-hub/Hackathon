export interface User {
  id: number;
  name: string;
  email: string;
}

export interface Chat {
  id: number;
  user_id: number;
  title: string;
  created_at: string;
}

export interface Message {
  id?: number;
  chat_id?: number;
  role: 'user' | 'ai';
  content: string;
  created_at?: string;
}

export type CoachingMode = 'coach' | 'negotiate' | 'salary' | 'mentor' | 'progress' | 'recruiter';
