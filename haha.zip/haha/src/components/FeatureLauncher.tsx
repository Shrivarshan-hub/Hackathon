import React from 'react';
import { CoachingMode } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, MessageCircle, Calculator, Users, TrendingUp, UserCheck, X } from 'lucide-react';

interface FeatureLauncherProps {
  isOpen: boolean;
  onClose: () => void;
  onOpen: () => void;
  onSelect: (mode: CoachingMode) => void;
}

export const FeatureLauncher: React.FC<FeatureLauncherProps> = ({ isOpen, onClose, onOpen, onSelect }) => {
  const features = [
    { id: 'coach', icon: <Sparkles />, label: 'Personal Assistant', color: 'rgba(124, 92, 252, 0.15)' },
    { id: 'coach', icon: <MessageCircle />, label: 'Help Chat Box', color: 'rgba(99, 102, 241, 0.15)' },
    { id: 'salary', icon: <Calculator />, label: 'Negotiation Calc', color: 'rgba(234, 179, 8, 0.15)' },
    { id: 'mentor', icon: <Users />, label: 'Personal Mentor', color: 'rgba(236, 72, 153, 0.15)' },
    { id: 'progress', icon: <TrendingUp />, label: 'Progress Tracker', color: 'rgba(59, 130, 246, 0.15)' },
    { id: 'recruiter', icon: <UserCheck />, label: 'AI Recruiter Sim', color: 'rgba(239, 68, 68, 0.15)' },
  ];

  return (
    <>
      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 z-[9997] bg-[#7c5cfc]/10 backdrop-blur-md"
          />
        )}
      </AnimatePresence>

      <button 
        onClick={isOpen ? onClose : onOpen}
        className={`fixed bottom-7 right-7 z-[9999] w-14 h-14 rounded-2xl bg-linear-to-br from-[#7c5cfc] to-[#c084fc] flex items-center justify-center text-2xl shadow-2xl transition-all duration-300 ${
          isOpen ? 'rotate-135 scale-105 !rounded-full !from-red-500 !to-rose-400 shadow-red-500/40' : 'hover:scale-110'
        }`}
      >
        {isOpen ? <X size={24} className="text-white" /> : '🌿'}
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ y: 20, scale: 0.92, opacity: 0 }}
            animate={{ y: 0, scale: 1, opacity: 1 }}
            exit={{ y: 20, scale: 0.92, opacity: 0 }}
            className="fixed bottom-24 right-7 z-[9998] w-80 glass-panel rounded-[28px] p-5 shadow-2xl origin-bottom-right"
          >
            <div className="flex items-center gap-3 pb-4 mb-4 border-b border-[#7c5cfc]/10">
              <div className="w-10 h-10 rounded-xl bg-linear-to-br from-[#7c5cfc] to-[#c084fc] flex items-center justify-center text-lg shadow-lg">🌿</div>
              <div>
                <div className="text-sm font-extrabold">SheThrive</div>
                <div className="text-[10px] text-muted">All features at your fingertips</div>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2.5">
              {features.map((f, i) => (
                <motion.button
                  key={i}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: i * 0.05 }}
                  onClick={() => {
                    onSelect(f.id as CoachingMode);
                    onClose();
                  }}
                  className="flex flex-col items-center justify-center gap-2 p-4 glass-panel rounded-2xl hover:-translate-y-1 hover:shadow-lg transition-all"
                >
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center text-xl" style={{ backgroundColor: f.color }}>
                    {f.icon}
                  </div>
                  <div className="text-[10px] font-bold text-center leading-tight">{f.label}</div>
                </motion.button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};
