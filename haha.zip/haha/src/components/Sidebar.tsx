import React from 'react';
import { User, Chat } from '../types';
import { LogOut, Plus, MessageSquare, Briefcase, Users, TrendingUp, Calculator, UserCheck } from 'lucide-react';

interface SidebarProps {
  user: User;
  chats: Chat[];
  activeChatId: number | null;
  onNewChat: () => void;
  onSelectChat: (id: number) => void;
  onLogout: () => void;
  onFeatureSelect: (mode: any) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ 
  user, chats, activeChatId, onNewChat, onSelectChat, onLogout, onFeatureSelect 
}) => {
  return (
    <aside className="w-64 flex-shrink-0 glass-panel flex flex-col h-full z-20">
      <div className="p-5 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-linear-to-br from-[#7c5cfc] to-[#c084fc] flex items-center justify-center text-white shadow-lg">
            🌿
          </div>
          <span className="font-extrabold text-lg tracking-tight">SheThrive</span>
        </div>
        <button 
          onClick={onNewChat}
          className="p-2 hover:bg-white/10 rounded-lg transition-colors"
        >
          <Plus size={18} />
        </button>
      </div>

      <button 
        onClick={onNewChat}
        className="mx-4 mb-4 p-2.5 bg-linear-to-br from-[#7c5cfc]/10 to-[#c084fc]/10 border border-[#7c5cfc]/20 rounded-xl text-[#7c5cfc] text-sm font-semibold flex items-center justify-center gap-2 hover:from-[#7c5cfc]/20 hover:to-[#c084fc]/20 transition-all"
      >
        <Plus size={16} /> New session
      </button>

      <div className="flex-1 overflow-y-auto px-2 space-y-1">
        <div className="text-[10px] font-bold text-dim uppercase tracking-widest px-3 py-2">Features</div>
        <button 
          onClick={() => onFeatureSelect('coach')}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium hover:bg-white/5 transition-all"
        >
          <Briefcase size={18} className="text-[#7c5cfc]" /> Career Coach
        </button>
        <button 
          onClick={() => onFeatureSelect('mentor')}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium hover:bg-white/5 transition-all"
        >
          <Users size={18} className="text-[#ec4899]" /> Find a Mentor
        </button>

        <div className="text-[10px] font-bold text-dim uppercase tracking-widest px-3 py-4">Recent</div>
        {chats.map(chat => (
          <button
            key={chat.id}
            onClick={() => onSelectChat(chat.id)}
            className={`w-full flex items-center gap-2 px-3 py-2 rounded-xl text-xs transition-all truncate ${
              activeChatId === chat.id ? 'bg-white/10 text-[#7c5cfc]' : 'text-muted hover:bg-white/5'
            }`}
          >
            <MessageSquare size={14} />
            <span className="truncate">{chat.title}</span>
          </button>
        ))}
      </div>

      <div className="p-4 border-t border-white/5">
        <div className="flex items-center gap-3 p-2 rounded-xl hover:bg-white/5 transition-all">
          <div className="w-9 h-9 rounded-full bg-linear-to-br from-[#7c5cfc] to-[#c084fc] flex items-center justify-center text-white font-bold shadow-md">
            {user.name.charAt(0).toUpperCase()}
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-sm font-bold truncate">{user.name}</div>
            <div className="text-[10px] text-dim truncate">SheThrive Pro</div>
          </div>
          <button onClick={onLogout} className="p-1.5 hover:bg-white/10 rounded-lg text-dim hover:text-red-400 transition-all">
            <LogOut size={16} />
          </button>
        </div>
      </div>
    </aside>
  );
};
