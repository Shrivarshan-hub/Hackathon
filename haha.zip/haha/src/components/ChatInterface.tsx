import React, { useState, useRef, useEffect } from 'react';
import { Message, CoachingMode } from '../types';
import { Send, Paperclip, Mic, MoreHorizontal, ThumbsUp, ThumbsDown, Copy, RotateCcw } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface ChatInterfaceProps {
  messages: Message[];
  onSendMessage: (text: string) => void;
  isBusy: boolean;
  mode: CoachingMode;
  userName: string;
}

export const ChatInterface: React.FC<ChatInterfaceProps> = ({ 
  messages, onSendMessage, isBusy, mode, userName 
}) => {
  const [input, setInput] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isBusy]);

  const handleSubmit = (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!input.trim() || isBusy) return;
    onSendMessage(input);
    setInput('');
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const welcomeChips = [
    { icon: '💰', title: 'Negotiate my salary', desc: 'Scripts and strategies to ask boldly', prompt: 'How do I negotiate a higher salary with confidence?' },
    { icon: '🧠', title: 'Beat imposter syndrome', desc: 'Build unshakeable inner confidence', prompt: 'I struggle with imposter syndrome. What should I do?' },
    { icon: '🎭', title: 'Practice negotiation', desc: 'Safe AI recruiter roleplay', prompt: 'Start an AI salary negotiation roleplay simulation with me.' },
    { icon: '📊', title: 'Know my market value', desc: 'Real salary benchmarks for my role', prompt: 'What is the salary range for a Product Manager with 5 years in Tech?' }
  ];

  return (
    <div className="flex-1 flex flex-col overflow-hidden relative">
      <div ref={scrollRef} className="flex-1 overflow-y-auto">
        {messages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center p-6 text-center">
            <motion.div 
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="text-6xl mb-4 drop-shadow-xl"
            >
              🌿
            </motion.div>
            <h2 className="text-3xl font-extrabold tracking-tight mb-2">Hello, {userName}!</h2>
            <p className="text-muted max-w-md mb-8 leading-relaxed">
              I'm your AI career coach, here to help you negotiate smarter, grow faster, and own your worth. What shall we tackle today?
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-2xl w-full">
              {welcomeChips.map((chip, i) => (
                <motion.button
                  key={i}
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: i * 0.1 }}
                  onClick={() => onSendMessage(chip.prompt)}
                  className="text-left p-4 glass-panel rounded-2xl hover:-translate-y-1 hover:shadow-xl transition-all group"
                >
                  <div className="text-2xl mb-2">{chip.icon}</div>
                  <div className="text-sm font-bold group-hover:text-[#7c5cfc] transition-colors">{chip.title}</div>
                  <div className="text-[11px] text-muted">{chip.desc}</div>
                </motion.button>
              ))}
            </div>
          </div>
        ) : (
          <div className="max-w-3xl mx-auto w-full px-6 py-8 space-y-8">
            {messages.map((msg, i) => (
              <motion.div 
                key={i}
                initial={{ y: 10, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                className="flex gap-4 items-start"
              >
                <div className={`w-8 h-8 rounded-lg flex-shrink-0 flex items-center justify-center text-sm font-bold shadow-md ${
                  msg.role === 'ai' 
                    ? 'bg-linear-to-br from-[#7c5cfc] to-[#c084fc] text-white' 
                    : 'bg-linear-to-br from-[#c084fc] to-[#7c5cfc] text-white'
                }`}>
                  {msg.role === 'ai' ? '🌿' : userName.charAt(0).toUpperCase()}
                </div>
                <div className="flex-1 space-y-1">
                  <div className="text-[11px] font-bold text-muted uppercase tracking-wider">
                    {msg.role === 'ai' ? 'SheThrive' : 'You'}
                  </div>
                  <div className="text-[15px] leading-relaxed whitespace-pre-wrap">
                    {msg.content}
                  </div>
                  {msg.role === 'ai' && (
                    <div className="flex gap-1 pt-2">
                      <button className="p-1.5 text-dim hover:text-white hover:bg-white/5 rounded-md transition-all"><Copy size={14} /></button>
                      <button className="p-1.5 text-dim hover:text-white hover:bg-white/5 rounded-md transition-all"><ThumbsUp size={14} /></button>
                      <button className="p-1.5 text-dim hover:text-white hover:bg-white/5 rounded-md transition-all"><ThumbsDown size={14} /></button>
                      <button className="p-1.5 text-dim hover:text-white hover:bg-white/5 rounded-md transition-all"><RotateCcw size={14} /></button>
                    </div>
                  )}
                </div>
              </motion.div>
            ))}
            {isBusy && (
              <div className="flex gap-4 items-start">
                <div className="w-8 h-8 rounded-lg bg-linear-to-br from-[#7c5cfc] to-[#c084fc] flex items-center justify-center text-white shadow-md">🌿</div>
                <div className="flex-1 space-y-1">
                  <div className="text-[11px] font-bold text-muted uppercase tracking-wider">SheThrive</div>
                  <div className="flex gap-1.5 items-center h-6">
                    <motion.div animate={{ opacity: [0.3, 1, 0.3] }} transition={{ repeat: Infinity, duration: 1 }} className="w-2 h-2 rounded-full bg-[#7c5cfc]" />
                    <motion.div animate={{ opacity: [0.3, 1, 0.3] }} transition={{ repeat: Infinity, duration: 1, delay: 0.2 }} className="w-2 h-2 rounded-full bg-[#7c5cfc]" />
                    <motion.div animate={{ opacity: [0.3, 1, 0.3] }} transition={{ repeat: Infinity, duration: 1, delay: 0.4 }} className="w-2 h-2 rounded-full bg-[#7c5cfc]" />
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      <div className="p-6 flex-shrink-0">
        <div className="max-w-3xl mx-auto w-full glass-panel rounded-3xl shadow-2xl overflow-hidden focus-within:ring-2 focus-within:ring-[#7c5cfc]/30 transition-all">
          <div className="flex gap-2 p-3 pb-1">
            <button className="px-3 py-1.5 rounded-full glass-panel text-[11px] font-bold text-muted hover:text-white transition-all flex items-center gap-1.5">
              <Paperclip size={12} /> Attach
            </button>
            <button className="px-3 py-1.5 rounded-full glass-panel text-[11px] font-bold text-muted hover:text-white transition-all flex items-center gap-1.5">
              <Mic size={12} /> Voice
            </button>
          </div>
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Message SheThrive..."
            className="w-full bg-transparent border-none outline-none p-4 pb-2 resize-none text-[15px] leading-relaxed placeholder:text-dim"
            rows={1}
            style={{ minHeight: '50px', maxHeight: '200px' }}
          />
          <div className="flex items-center justify-between p-3 pt-0">
            <span className="text-[10px] text-dim px-1">Enter to send · Shift+Enter for new line</span>
            <button 
              onClick={() => handleSubmit()}
              disabled={!input.trim() || isBusy}
              className="w-9 h-9 rounded-xl bg-linear-to-br from-[#7c5cfc] to-[#c084fc] flex items-center justify-center text-white shadow-lg hover:scale-110 active:scale-95 disabled:opacity-50 disabled:scale-100 transition-all"
            >
              <Send size={16} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
