import React, { useState } from 'react';
import { User } from '../types';
import { motion, AnimatePresence } from 'motion/react';

interface AuthProps {
  onLogin: (user: User) => void;
}

export const Auth: React.FC<AuthProps> = ({ onLogin }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, name: name || email.split('@')[0] })
      });
      const user = await res.json();
      onLogin(user);
    } catch (error) {
      console.error("Login error:", error);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-6">
      <div className="absolute inset-0 bg-black/20 backdrop-blur-sm" />
      
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="w-full max-w-md relative"
      >
        <div className="text-center mb-8">
          <div className="inline-flex w-16 h-16 rounded-2xl bg-linear-to-br from-[#7c5cfc] to-[#c084fc] items-center justify-center text-3xl mb-4 shadow-2xl">
            🌿
          </div>
          <h1 className="text-3xl font-extrabold tracking-tight">SheThrive</h1>
          <p className="text-muted mt-2">AI-powered career coaching for women</p>
        </div>

        <div className="glass-panel rounded-[32px] p-8 shadow-2xl">
          <h2 className="text-xl font-bold mb-1">{isLogin ? 'Welcome back' : 'Create account'}</h2>
          <p className="text-xs text-muted mb-6">{isLogin ? 'Sign in to continue your journey' : 'Join thousands of women thriving'}</p>

          <div className="flex gap-3 mb-6">
            <button className="flex-1 py-2.5 rounded-xl glass-panel text-xs font-bold hover:bg-white/10 transition-all flex items-center justify-center gap-2">
              <span className="text-blue-500">G</span> Google
            </button>
            <button className="flex-1 py-2.5 rounded-xl glass-panel text-xs font-bold hover:bg-white/10 transition-all flex items-center justify-center gap-2">
              <span></span> Apple
            </button>
          </div>

          <div className="flex items-center gap-4 mb-6 text-[10px] font-bold text-dim uppercase tracking-widest">
            <div className="flex-1 h-px bg-white/10" />
            or continue with email
            <div className="flex-1 h-px bg-white/10" />
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {!isLogin && (
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-muted uppercase tracking-wider">Full Name</label>
                <input 
                  type="text" 
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Jane Doe"
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm outline-none focus:border-[#7c5cfc] transition-all"
                />
              </div>
            )}
            <div className="space-y-1.5">
              <label className="text-[10px] font-bold text-muted uppercase tracking-wider">Email Address</label>
              <input 
                type="email" 
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="jane@example.com"
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm outline-none focus:border-[#7c5cfc] transition-all"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-[10px] font-bold text-muted uppercase tracking-wider">Password</label>
              <input 
                type="password" 
                placeholder="••••••••"
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm outline-none focus:border-[#7c5cfc] transition-all"
              />
            </div>

            <button 
              type="submit"
              className="w-full py-3.5 bg-linear-to-br from-[#7c5cfc] to-[#c084fc] rounded-xl text-white font-bold text-sm shadow-xl hover:shadow-[#7c5cfc]/30 hover:-translate-y-0.5 transition-all mt-4"
            >
              {isLogin ? 'Sign In' : 'Create Account'} →
            </button>
          </form>

          <p className="text-center mt-6 text-xs text-muted">
            {isLogin ? "No account? " : "Have an account? "}
            <button 
              onClick={() => setIsLogin(!isLogin)}
              className="text-[#7c5cfc] font-bold hover:underline"
            >
              {isLogin ? 'Create one' : 'Sign in'}
            </button>
          </p>
        </div>
      </motion.div>
    </div>
  );
};
